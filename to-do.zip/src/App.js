import './App.css';
import React, { useState, useEffect } from 'react';
// import { Route, Link, Routes, Navigate } from 'react-router-dom';
import axios from 'axios';
import pencil from './img/pencil.svg';
import cross from './img/cross.svg'

function App() {
  const [text, setText] = useState('');
  const [tasks, setTask] = useState([]);
  // const [editTask, setEditTask] = useState(null);

  const url = `http://localhost:8000/`;

  useEffect (async() => {
    await axios.get(`${url}allTasks`).then(res => {
      setTask(res.data);
    })
  }, [1])
  
  const addNewTask = async () => {
    await axios.post(`${url}createTask`, {
      text,
      isCheck: false
    }).then(res => {
      setText('');
      const updatedList = [...tasks, res.data];
      setTask(updatedList)
    })
  } 

  const deleteTask = async (_id, index) => {
    await axios.delete(`${url}deleteTask?_id=${_id}`).then((res) => {
      if (res.status === 200) {
      const stayedTasks = tasks.filter((i)=> i._id != _id);
      setTask(stayedTasks)
      }
    })
  }

  return (
    <div>
      <header>
        <h1>Список дел</h1>
        <input type='text' value={text} onChange={(e) => setText(e.target.value)} />
        <button onClick={() => addNewTask()}>Добавить</button>
      </header>
      {
        tasks.map((task, index) => {
          <div key={`task${task._id}`}>
            <input type='checkbox'checked={task.isCheck} /> 
            <p>{task.text}</p>
            <img src={pencil} alt={"edit"} />
            <img src={cross} alt={"delete"} onClick={() => deleteTask(task._id, index)}/>
          </div>
        }) 
      }
    </div>
  )
}

export default App;

// onClick={() => setEditTask(task)} 
// editTask === task ? 
          // <div key={`task${task._id}`}>
          //   <input type='checkbox'checked={task.isCheck} />
          //   <input type='text' value={text} />
          //   <img src={cross} alt={"delete"} onClick={() => deleteTask(task._id, index)}/>
          // </div>
        
        // : 