import './App.css';
import React from 'react';
import { Routes, Route, useHistory } from 'react-router-dom';

function Company ({currentCompany}) {
  console.log(currentCompany)
  return (
    <div>
      <h2>Company {currentCompany.company}</h2>
    </div>
  )
}

export default Company;


