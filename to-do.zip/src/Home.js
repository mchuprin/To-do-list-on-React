import './App.css';
import React, { useState } from 'react';
import { Routes, Route, useNavigate, Navigate } from 'react-router-dom';
import Company from './Company';


function Home () {

  let history = useNavigate();

  const [currentCompany, setCompany] = useState({})

  const companies = [{
    company: 'Gaga',
    owner: 'Ivan',
    id: 1
  },
  {
    company: 'Gugu',
    owner: 'Ivun',
    id: 2
  },
  {
    company: 'Gogo',
    owner: 'Ivon',
    id: 3
  },
  {
    company: 'Gigi',
    owner: 'Ivin',
    id: 4
  }
  ]

  const goToCompany = (index) => {
    setCompany(companies[index]);
    history(`${companies[index].id}`)
  }

  return (
    <div>
      <h1>Home</h1>
      {
        companies.map((value, index) => 
        <div key={`company${index}`} onClick={() => goToCompany(index)}>
          <h3>{value.company}</h3>
          <p>{value.owner}</p>
        </div>)
      }
      <Routes>
        <Route path=':id' element={<Company currentCompany={currentCompany}/>} />
      </Routes>
    </div>
  )
}

export default Home;


