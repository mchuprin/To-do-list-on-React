import './App.css';
import React from 'react';

function Post () {
  return (
    <h1>Post</h1>
  )
}

export default Post;